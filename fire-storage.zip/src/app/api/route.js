

export function GET(req) {

    return Response.json([])
}
